# Bo Tholo Mining & Governance Hub

A static GitHub Pages register for mines, traditional leadership records, community trusts, Social and Labour Plan (SLP) projects, permits, documents and contacts.

## Important

This is a **static website**. There is no server, database, login system or secure admin backend.

The `admin.html` page only generates JavaScript snippets in the visitor's browser. It **does not save data to GitHub automatically**.

Do not put passwords, API keys, private identity documents, confidential contracts or other sensitive information into `assets/js/data.js`.

## Project structure

```text
bo-tholo-hub/
├── index.html
├── kings.html
├── demographics.html
├── mines.html
├── map.html
├── trusts.html
├── projects.html
├── permits.html
├── documents.html
├── contacts.html
├── admin.html
├── 404.html
├── robots.txt
├── README.md
└── assets/
    ├── css/
    │   └── style.css
    └── js/
        ├── app.js
        └── data.js
```

## GitHub Pages deployment

1. Create a new GitHub repository.
2. Upload **all files and folders**, preserving the structure above.
3. Open **Settings → Pages**.
4. Under the deployment/build section, choose **Deploy from a branch**.
5. Select the branch containing these files, normally `main`.
6. Select `/ (root)` as the folder.
7. Save.
8. Wait for GitHub Pages to publish the site.
9. Open the Pages URL shown by GitHub.

The site requires no Node.js build process.

## Updating data

The safest workflow for a novice is:

1. Open `admin.html` on the published site.
2. Select the record type.
3. Complete the form.
4. Generate the snippet.
5. Copy the snippet.
6. Open `assets/js/data.js` in GitHub.
7. Paste the new object into the correct array.
8. Commit the change.
9. Wait for GitHub Pages to redeploy.

Before publishing factual records, verify them against the authoritative source and record the source/reference in the data.

## Professional data-governance recommendation

For every real record, keep a source trail:

- source organisation
- source document/report title
- source date
- reference number where applicable
- URL where publicly available
- date last verified
- person/office responsible for verification

The current site is deliberately marked with placeholder data. Replace placeholders only after verification.

## Current terminology

The site uses **Social and Labour Plan (SLP)** rather than "SLA", matching South African mining terminology.

The district name is written as **John Taolo Gaetsewe**.

Mining-right information should be checked against the current Department of Mineral and Petroleum Resources (DMPR) systems. Legacy SAMRAD may still appear in older records and references.

## Recommended next development phase

For a genuinely production-grade governance system, the next step should be:

- a real database
- authenticated administrator accounts
- role-based permissions
- audit history
- record IDs
- document storage with access control
- source/verification fields
- automated backups
- server-side validation
- change approval workflow
- automated data-quality checks
- HTTPS and security headers
- automated tests in GitHub Actions

Until those features exist, treat this GitHub Pages version as a **public-facing static register/prototype**, not a secure records-management system.


## Security: why the public site has no admin page

This GitHub Pages build intentionally does **not** publish `admin.html`. GitHub Pages serves static files publicly, so a browser-only admin page cannot provide real authentication or access control.

To update data, edit `assets/js/data.js` in a controlled GitHub workflow (or use the separate local maintainer tool supplied outside the public site). Never commit passwords, API keys, private documents, confidential agreements, banking details, or sensitive personal information to this public repository.

The separate `bo-tholo-private-admin` package is a local helper only. **Do not upload it to GitHub Pages.**
